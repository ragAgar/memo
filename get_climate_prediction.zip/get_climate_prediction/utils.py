import time, json
import requests
import numpy as np
from bs4 import BeautifulSoup

def get_soup(URL):
    headers = { "User-Agent" :  "Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)" }
    resp = requests.get(URL, timeout=2, headers=headers)
    r_text = resp.text

    soup = BeautifulSoup(r_text, 'html.parser')
    time.sleep(0.2)
    return soup

def text2soup(text):
    return BeautifulSoup(text, 'html.parser')

def get_date(trs):
    in_nen = "年" in str(trs)
    in_month = "月" in str(trs)
    in_day = "日" in str(trs)
    in_date = in_nen + in_month + in_day
    return in_date == 3

def get_day(trs):
    in_month = "月" in str(trs)
    in_day = "日" in str(trs)
    in_date = in_month + in_day
    return in_date == 2

def get_merged_soup_by_i(trs, i, date_array):
    res_text = ""
    for tr in np.asarray(trs)[date_array == i]:
        res_text += str(tr)
    return text2soup(res_text)

def get_after_day(start_date, **kwargs):
    return start_date + timedelta(**kwargs)

def save_json(path, X):
    with open(path, mode='w') as f:
        json.dump(X, f)
    
def load_json(path):
    with open(path, mode='r') as f:
        return json.load(f)