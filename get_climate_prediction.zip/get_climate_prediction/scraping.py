from tqdm import tqdm
import os, time, json
import requests
import utils as ut
import numpy as np
from bs4 import BeautifulSoup
from datetime import datetime


def main():
    onehour_res_json = {}
    oneday_res_json = {}
    oneday_res_detail_json = {}

    URL = 'https://tenki.jp/'
    add_html = ["1hour.html", "10days.html"]

    base_soup = ut.get_soup(URL)
    areas = base_soup.find_all("a", attrs={"class": "pref-link"})
    #都道府県
    for area in tqdm(areas):
        add_url = area.attrs["href"][1:]
        area_soup = ut.get_soup(URL + add_url)
        
        forecast_point_soup = area_soup.find_all("ul", attrs={"class":"forecast-point-entries"})
        #さらに詳細なエリア
        for i in tqdm(range(len(forecast_point_soup))):
            forecast_point_soup_detail = forecast_point_soup[i].find_all("a")
            
            for i2 in range(len(forecast_point_soup_detail)):
                add_url = forecast_point_soup_detail[i2].attrs["href"][1:]
                area_forecast_point = ut.get_soup(URL + add_url)

                #1時間天気予報, 10日天気予報 
                scraping_url = URL + add_url + add_html[0]
                scraping_soup = ut.get_soup(scraping_url)
                place = scraping_soup.title.text[:-24]
                ##
                onehour_res_json[place] = {}

                trs = scraping_soup.find_all("tr")
                date_array = np.cumsum([ut.get_date(tr) for tr in trs]) - 1

                ##soup
                soup  = ut.get_merged_soup_by_i(trs=trs, i = 0, date_array=date_array)
                onehour_res_json[place][soup.find("p").text] = {}
                onehour_res_json[place][soup.find("p").text]["hour"] = [int(hour_tag.text) for hour_tag in soup.find("tr", attrs = {"class":"hour"}).find_all("td")]
                onehour_res_json[place][soup.find("p").text]["weather"] = [weather_tag.attrs["alt"] for weather_tag in soup.find("tr", attrs = {"class":"weather"}).find_all("img")]
                onehour_res_json[place][soup.find("p").text]["temperature"] = [float(temp_tag.text) for temp_tag in soup.find("tr", attrs = {"class":"temperature"}).find_all("span")]
                onehour_res_json[place][soup.find("p").text]["prob-precip"] = [float(precip_tag.text) for precip_tag in soup.find("tr", attrs={"class":"prob-precip"}).find_all("span")[1:]]
                onehour_res_json[place][soup.find("p").text]["humidity"] = [float(humidity_tag.text) for humidity_tag in soup.find("tr", attrs={"class":"humidity"}).find_all("span")[1:]]
                onehour_res_json[place][soup.find("p").text]["precip-vol"] = [float(precipgraph_tag.attrs["alt"]) for precipgraph_tag in soup.find("tr", attrs={"class":"precip-graph"}).find_all("img")]
                onehour_res_json[place][soup.find("p").text]["wind-blow"] = [windblow_tag.attrs["alt"] for windblow_tag in soup.find("tr", attrs={"class":"wind-blow"}).find_all("img")]
                onehour_res_json[place][soup.find("p").text]["wind-speed"] = [float(windspeed.text) for windspeed in soup.find("tr", attrs={"class":"wind-speed"}).find_all("span")]

                ##
                for j in [1,2]:
                    soup_sub  = ut.get_merged_soup_by_i(trs=trs, i = j, date_array=date_array)
                    #one hour
                    onehour_res_json[place][soup.find("p").text]["day%s_hour"%(j)] = [int(hour_tag.text) for hour_tag in soup.find("tr", attrs = {"class":"hour"}).find_all("td")]
                    onehour_res_json[place][soup.find("p").text]["day%s_weather"%(j)] = [weather_tag.attrs["alt"] for weather_tag in soup.find("tr", attrs = {"class":"weather"}).find_all("img")]
                    onehour_res_json[place][soup.find("p").text]["day%s_temperature"%(j)] = [float(temp_tag.text) for temp_tag in soup.find("tr", attrs = {"class":"temperature"}).find_all("span")]
                    onehour_res_json[place][soup.find("p").text]["day%s_prob-precip"%(j)] = [float(precip_tag.text) for precip_tag in soup.find("tr", attrs={"class":"prob-precip"}).find_all("span")[1:]]
                    onehour_res_json[place][soup.find("p").text]["day%s_humidity"%(j)] = [float(humidity_tag.text) for humidity_tag in soup.find("tr", attrs={"class":"humidity"}).find_all("span")[1:]]
                    onehour_res_json[place][soup.find("p").text]["day%s_precip-vol"%(j)] = [float(precipgraph_tag.attrs["alt"]) for precipgraph_tag in soup.find("tr", attrs={"class":"precip-graph"}).find_all("img")]
                    onehour_res_json[place][soup.find("p").text]["day%s_wind-blow"%(j)] = [windblow_tag.attrs["alt"] for windblow_tag in soup.find("tr", attrs={"class":"wind-blow"}).find_all("img")]
                    onehour_res_json[place][soup.find("p").text]["day%s_wind-speed"%(j)] = [float(windspeed.text) for windspeed in soup.find("tr", attrs={"class":"wind-speed"}).find_all("span")]


                #10days
                scraping_url = URL + add_url + add_html[1]
                scraping_soup = ut.get_soup(scraping_url)
                place = scraping_soup.title.text[:-32]
                trs = scraping_soup.find_all("tr")
                day_array = np.cumsum([ut.get_day(day_tag) for day_tag in trs]) - 1
                oneday_res_json[place]  = {}
                oneday_res_detail_json[place] = {}
                unique_day = np.unique(day_array)[np.unique(day_array) >= 0]
                for u_day in unique_day:
                    if u_day == 0:
                        day_tag = ut.get_merged_soup_by_i(trs, u_day, day_array)
                        ths = day_tag.find_all("th")

                        day = ths[0].text
                        oneday_res_json[place][day] = {}
                        oneday_res_json[place][day]["weather"] = ths[1].text
                        oneday_res_json[place][day]["high-temp"] = ths[2].find_all("span", attrs={"class":"high-temp"})[0].text
                        oneday_res_json[place][day]["low-temp"] = ths[2].find_all("span", attrs={"class":"low-temp"})[0].text        

                        oneday_res_detail_json[place][day] = {}

                        day_tag = ut.get_merged_soup_by_i(trs, u_day, day_array)
                        ths = day_tag.find_all("th")
                        oneday_res_json[place][day]["%s_weather"%(u_day)] = ths[1].text
                        oneday_res_json[place][day]["%s_high-temp"%(u_day)] = ths[2].find_all("span", attrs={"class":"high-temp"})[0].text
                        oneday_res_json[place][day]["%s_low-temp"%(u_day)] = ths[2].find_all("span", attrs={"class":"low-temp"})[0].text

                        #時間毎

                        for k in [1, 2, 3, 4]:
                            day_detail_tag = day_tag.find_all("tr")[k]
                            day_detail_tag = day_detail_tag.find_all("td")
                            oneday_res_detail_json[place][day]["%s_%s_weather"%(u_day, day_detail_tag[0].text)] = day_detail_tag[1].text
                            oneday_res_detail_json[place][day]["%s_%s_temperature"%(u_day, day_detail_tag[0].text)] = day_detail_tag[2].text            
                            oneday_res_detail_json[place][day]["%s_%s_prob-precip"%(u_day, day_detail_tag[0].text)] = day_detail_tag[3].text             
                            oneday_res_detail_json[place][day]["%s_%s_prob-vol"%(u_day, day_detail_tag[0].text)] = day_detail_tag[4].text        
                            oneday_res_detail_json[place][day]["%s_%s_humidity"%(u_day, day_detail_tag[0].text)] = day_detail_tag[5].text         
                            oneday_res_detail_json[place][day]["%s_%s_wind-blow"%(u_day, day_detail_tag[0].text)] = day_detail_tag[6].find("img").attrs["alt"]           
                            oneday_res_detail_json[place][day]["%s_%s_wind-speed"%(u_day, day_detail_tag[0].text)] = day_detail_tag[6].text
    now = datetime.now()
    ut.save_json(path = "./serialize/oneday_res_%s_%s_%s.json"%(now.year, now.month, now.day), X = oneday_res_json)
    ut.save_json(path = "./serialize/oneday_res_detail_%s_%s_%s.json"%(now.year, now.month,now.day), X = oneday_res_detail_json)    
    ut.save_json(path = "./serialize/onehour_res_%s_%s_%s.json"%(now.year, now.month,now.day), X = onehour_res_json)

if __name__ == '__main__':
    while True:
        now = datetime.now()
        try:
            os.system('clear')
            print(now)
            main()
            time.sleep(60*60*24 + 1)
        except KeyboardInterrupt:
          break
